<html>
    <header>
    </header>

        <body>
        </body>

    <foter>
    </foter>


</html>

<?php
$a = 1;
$b = 2;

if($a > $b){
    echo "a maior que b";
}

else if($a == $b){
    echo "a é igual a b";
}
else{
    echo "a é menor que b";
}
?>