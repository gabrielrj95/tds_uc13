<html>
    <head>
        <h1>Exemplo 02</h1>
    </head>

    <body>
    Olá mundo! Sou html
    <?php
    echo "<br>Olá mundo";
    ?>
    </body>

</html>