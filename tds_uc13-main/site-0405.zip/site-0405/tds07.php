<?php
$var1 = "Ola";
$var2 = "Mundo";
echo $var1 . $var2;
echo "<br>";
echo "Concatenando texto".$var1;
echo "<br>";
$var3 = 10;
echo "Teste ".$var3;
echo "<br>";
//???????????
$var1.= $var2;
$var4 = $var1 . " ".$var2;
echo "<br>";
echo $var4;

?>