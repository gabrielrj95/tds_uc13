<?php

echo "Olá mundo";

?>

<h1>TITULO</h1>

<?php

echo "Curso Senac";

echo "Programação Back End";

?>