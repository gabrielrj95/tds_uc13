<?php

echo "Olá mundo";

?>