<?php
$var1 = 5;
$var2 = 10.5;
$var3 = "Curso Senac";
$soma = $var1 + $var2;
$soma2 = $var1 + $var3;

echo $var1;
echo "<br>";
echo $var2;
echo "<br>";
echo $var3;
echo "<br>";
echo $soma;
echo "<br>";
echo $soma2;

?>  