<?php

echo "Olá mundo sou Index";

?>