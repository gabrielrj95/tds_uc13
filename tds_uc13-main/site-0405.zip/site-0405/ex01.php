<html>
    <body>
        Texto HTML
        <table border="1">
        <?php
            $entrada = 4;

            for($i=0; $i <=10; $i++){
            $multi = $entrada * $i;
            echo "<tr><td>". $entrada ."X". $i. "= ".$multi . "<br>" . "</td></td>";
            }
            ?>
        </table>
    <header>
    </header>

<main>
</main>

<foter>
</foter>

</body>
</html>